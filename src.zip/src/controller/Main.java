package controller;

import model.Plateau;
import model.Plateau;

public class Main {
	
	public static void main(String arg[]){
		
		Plateau modele = new Plateau();
		FourmiController controleur=new FourmiController(modele);
		return;
		
	}

}
