package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import model.Plateau;

import java.awt.geom.*;

public class GrillePanel extends JPanel
{
	private volatile Plateau grille = null;
	
	public GrillePanel()
	{
		super();
	}
	
	public void setGrille(Plateau p)
	{
		this.grille = p;
	}
	
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		for(int i = 0; i < Plateau.size; i++) {
			for(int j = 0; j < Plateau.size; j++) {
				if((grille != null)) 
				{
						Color c = g2d.getColor();
						if( grille.getCouleurCase(i,j) == 1)
							g2d.setColor(Color.PINK);
						if( grille.getCouleurCase(i,j) == 2)
							g2d.setColor(Color.CYAN);
						if( grille.getCouleurCase(i,j) == 3)
							g2d.setColor(Color.ORANGE);
						if( grille.getCouleurCase(i, j) == -1)
							g2d.setColor(Color.GREEN);
						if(grille.getCouleurCase(i,j) != 0)
							g2d.fill(new Rectangle(j*10, i*10, 10, 10));
						g2d.setColor(c);
						g2d.draw(new Rectangle(j*10, i*10, 10, 10));
					
					if(!grille.caseLibre(i, j))
					{
						if(grille.getCouleurFourmi(i, j)==1)
							g2d.setColor(Color.RED);
						if(grille.getCouleurFourmi(i, j)==2)
							g2d.setColor(Color.BLUE);
						if(grille.getCouleurFourmi(i, j)==3)
							g2d.setColor(Color.YELLOW);
						g2d.fill(new Rectangle(j*10+2, i*10+2, 6, 6));
						g2d.setColor(c);
					}
				} 
				else
					g2d.draw(new Rectangle(j*10, i*10, 10, 10));
				
			}
		}
	}
}