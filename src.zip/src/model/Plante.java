package model;

public class Plante extends Case{

	public Plante(){
		this.setCouleur(-1);
	}
	
}
